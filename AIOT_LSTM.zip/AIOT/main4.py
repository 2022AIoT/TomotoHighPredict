import torch
from torch import nn, optim
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import MinMaxScaler
from torch.utils.tensorboard import SummaryWriter
from torchvision import transforms
import torch.nn.functional as F
import numpy as np
import pandas as pd
import math
import torch
from torch.utils.data import Dataset, DataLoader

excel_file = 'output6.xlsx'
# columns = ['编号', '叶面积', '叶夹角', '高度', 'NDVI', 'RVI', 'LNC', 'LNA', 'LAI', 'LDW', '采集时间']

class CustomDataset(Dataset):
    def __init__(self, data):
        self.data = pd.read_excel(excel_file)
        self.embedding = nn.Embedding(540, 24)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        sample = self.data.iloc[index]
        data = [sample['叶面积'],sample['叶夹角'],sample['高度'],sample['空气温度'],sample['相对湿度'],sample['光照'],sample['二氧化碳'],sample['土壤水分'],sample['土壤温度'],sample['KNO3'],sample['NH4H2PO4'],sample['K2SO4'],sample['MgSO4.7H2O'],sample['CaCl2'],sample['CaNO3.4H2O']]
        lable = [sample['高度']]
        with torch.no_grad():
            prev = torch.cat([self.embedding(torch.tensor(sample['KNO3'])), self.embedding(torch.tensor(sample['NH4H2PO4'])),self.embedding(torch.tensor(sample['K2SO4'])),self.embedding(torch.tensor(sample['MgSO4.7H2O'])),self.embedding(torch.tensor(sample['CaCl2'])),self.embedding(torch.tensor(sample['CaNO3.4H2O']))])
        id = [sample['处理'],sample['品种'],sample['编号']]
        return data, prev, lable, id

# 创建自定义数据集
dataset = CustomDataset(excel_file)

# 创建数据加载器
batch_size = 56 #总天数
dataloader = DataLoader(dataset, batch_size=batch_size)

# 遍历数据加载器进行批量加载数据
#for batch in dataloader:
    # 处理批量数据
    # print(batch)

class LSTMCell(torch.nn.Module):
    def __init__(self, input_size, hidden_size):
        super(LSTMCell, self).__init__()

        self.input_size = input_size
        self.hidden_size = hidden_size
        self.weight_ih = torch.nn.Parameter(torch.Tensor(4 * hidden_size, input_size))
        self.weight_hh = torch.nn.Parameter(torch.Tensor(4 * hidden_size, hidden_size))
        self.bias_ih = torch.nn.Parameter(torch.Tensor(4 * hidden_size))
        self.bias_hh = torch.nn.Parameter(torch.Tensor(4 * hidden_size))

        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1.0 / math.sqrt(self.hidden_size)
        for weight in self.parameters():
            torch.nn.init.uniform_(weight, -stdv, stdv)

    def forward(self, input, hx):
        h, c = hx
        # 四个门控用4倍大矩阵一起算，然后分割成四个
        gates = torch.matmul(input, self.weight_ih.t()) + self.bias_ih + torch.matmul(h, self.weight_hh.t()) + self.bias_hh
        ingate, forgetgate, cellgate, outgate = gates.chunk(4, 0)

        ingate = torch.sigmoid(ingate)
        forgetgate = torch.sigmoid(forgetgate)
        cellgate = torch.tanh(cellgate)
        outgate = torch.sigmoid(outgate)

        cy = (forgetgate * c) + (ingate * cellgate)
        hy = outgate * torch.tanh(cy)

        return hy, cy


class Model(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_days):
        super(Model, self).__init__()
        self.hidden_dim = hidden_dim

        self.lstm = LSTMCell(input_dim, hidden_dim)
        self.fc1 = nn.Linear(hidden_dim * 2, hidden_dim * 2)
        self.fc2 = nn.Linear(hidden_dim * 2, num_days)
        self.dropout = nn.Dropout()

    # def forward(self, x, st, y, op, device):


# 设置超参数
input_dim = 30
hidden_dim = 144
num_days = 7
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(device)

model = Model(input_dim, hidden_dim, num_days).to(device)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), weight_decay=1e-5)
writer = SummaryWriter("logs_LSTM4")

# 训练循环
num_epochs = 100
#model.load_state_dict(torch.load('model_AIOT_LSTM.pt'))
for epoch in range(num_epochs):

    train_loss = 0
    test_loss = 0
    for (pic, (x, st, y, id)) in enumerate(dataloader):
        if pic==57 | pic==2 | pic ==34|pic ==37|pic ==33|pic ==50|pic ==71:
            continue
        X = []
        div = [4, 2, 12]
        for i in range(3):
            for j in range(div[i]):
                X.append(x[i])
        for i in range(3, len(x)):
            X.append(x[i])
        inp = []
        for step in range(batch_size):
            inp_step = []
            for item in X:
                inp_step.append(item[step])
            inp.append(inp_step)
        scaler = MinMaxScaler()
        inp = scaler.fit_transform(inp)
        inp = torch.tensor(inp).to(torch.float32)
        if id[2][0] % 3 != 0:
            model.train()
            for lenth in range(21,batch_size - num_days):
                hidden = st[0].to(device).to(torch.float32)
                c = st[0].to(device).to(torch.float32)
                for step in range(lenth):
                    hidden, c = model.lstm.forward(inp[step], (hidden, c))

                out = torch.cat((hidden, c))
                out = model.dropout(model.fc1(out))
                outputs = model.fc2(out)
                loss = criterion(outputs, y[0][lenth:lenth + num_days].to(torch.float32))
                train_loss += loss.item()

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
        else:
            model.eval()
            with torch.no_grad():
                for lenth in range(21,batch_size - num_days):
                    hidden = st[0].to(device).to(torch.float32)
                    c = st[0].to(device).to(torch.float32)
                    for step in range(lenth):
                        hidden, c = model.lstm.forward(inp[step], (hidden, c))

                    out = torch.cat((hidden, c))
                    out = model.dropout(model.fc1(out))
                    outputs = model.fc2(out)

                    loss = criterion(outputs, y[0][lenth:lenth + num_days].to(torch.float32))
                    test_loss += loss.item()
    train_loss /= 2
    writer.add_scalar('Train/Loss', train_loss, epoch)
    writer.add_scalar('Test/Loss', test_loss, epoch)
    print('Train Epoch: {} \tTrain_Loss: {:.6f}\tTest_Loss: {:.6f}'.format(epoch, train_loss, test_loss))
    torch.save(model.state_dict(), 'model_AIOT_LSTM4.pt')
writer.close()
